package paquete1;

import java.util.ArrayList;

public class EstudianteDistancia extends Estudiante {

    private ArrayList<Nota> notas;
    private double mejorNota;
    private double peorNota;
    private double promedio;

    public void establecerNotas(ArrayList<Nota> ns) {
        notas = ns;
    }

    public void establecerMejorNota() {
        double mejorNota = 0;
        for (int i = 0; i < notas.size(); i++) {
            if (obtenerNotas().get(i).obtenerValor() > mejorNota){
        }
    }

    public void establecerPeorNota(double peor) {
        peorNota = 5.0;
    }

    public void establecerPromedio() {
        double suma = 0;
        for (int i = 0; i < notas.size(); i++) {
            suma += notas.get(i).obtenerValor();
        }
        promedio = suma / notas.size();
    }

    public void obtenerNotas(ArrayList<Nota> ns) {
        notas = ns;
    }

    public double obtenerMejorNota() {
        return mejorNota;
    }

    public double obtenerPeorNota() {
        return peorNota;
    }

    public double obtenerPromedio() {
        return promedio;
    }

    @Override
    public String toString() {
        return "";
    }

}
